# Scolaris – installer et utiliser l'application

Contenu du dossier : `index.html` (l'application), `manifest.webmanifest`, `sw.js` (mode hors ligne), `icons/`.
Tous les fichiers doivent rester ensemble, dans le même dossier.

## 1. Publier gratuitement (une seule fois, avec internet)
Une application installable doit être servie en HTTPS. Choisissez UNE option :

**Netlify (le plus simple)** : allez sur app.netlify.com/drop, créez un compte gratuit, puis glissez-déposez le dossier `scolaris-pwa`. Vous obtenez une adresse du type `https://xxxx.netlify.app`.

**GitHub Pages** : créez un dépôt GitHub public, envoyez-y tous les fichiers, puis Settings > Pages > Branch `main` > Save. Adresse : `https://votre-nom.github.io/nom-du-depot/`.

**Cloudflare Pages** : Workers & Pages > Create > Pages > Upload assets, puis déposez le dossier.

## 2. Installer
**Android (Chrome)** : ouvrez l'adresse, attendez quelques secondes, menu ⋮ > « Installer l'application » (ou « Ajouter à l'écran d'accueil »). L'icône Scolaris apparaît parmi vos applications.
**Ordinateur (Chrome ou Edge)** : ouvrez l'adresse, cliquez sur l'icône d'installation dans la barre d'adresse (écran avec une flèche) ou menu > « Installer Scolaris ».
**iPhone (Safari)** : Partager > Sur l'écran d'accueil.

Après la première ouverture avec internet, l'application s'ouvre et fonctionne SANS connexion.

## 3. Données : à lire absolument
- Les données sont enregistrées sur l'appareil utilisé. Deux appareils = deux jeux de données distincts (pas de synchronisation dans cette version).
- Effacer les données du navigateur ou désinstaller l'application efface les données.
- Faites régulièrement Réglages > « Sauvegarder les données » et conservez le fichier (clé USB, e-mail). Pour passer d'un appareil à l'autre : sauvegarde sur le premier, « Restaurer une sauvegarde » sur le second.
- Code d'accès : Réglages > Sécurité et données. En cas d'oubli du code, il faut effacer les données de l'application puis restaurer une sauvegarde.

## 4. Imprimer les bulletins
Aperçu des bulletins > « Imprimer tous les bulletins ». Dans la fenêtre d'impression, choisissez une imprimante ou « Enregistrer au format PDF ».

## 5. Mettre à jour
Après modification de `index.html`, changez `VERSION` dans `sw.js` (ex. `scolaris-v2`), republiez : l'application se met à jour à la réouverture suivante.

## 6. Pour aller plus loin
Version APK ou installeur Windows : pwabuilder.com (gratuit), en saisissant l'adresse publiée.
Version multi-appareils avec comptes et synchronisation : nécessite un serveur et une base de données en ligne (étape suivante possible).
